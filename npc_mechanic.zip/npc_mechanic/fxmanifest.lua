fx_version 'cerulean'
game 'gta5'

author 'Myzex'
description 'NPC Mechanic Script'
version '1.1.0'

client_scripts {
    'config.lua',
    'client/client.lua'
}
