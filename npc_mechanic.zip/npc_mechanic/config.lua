Config = {}

-- Vehicle model name for the tow truck
Config.TowTruckModel = "19raptor" 

-- NPC model for the mechanic
Config.MechanicPedModel = "s_m_m_autoshop_01"

-- Tow truck color (primary, secondary) - GTA color ID
Config.TowTruckColor = { primary = 88, secondary = 88 } -- Yellow

-- Distance mechanic spawns from player (in meters)
Config.SpawnDistance = 200.0

-- Distance mechanic drives away before despawn (in meters)
Config.DespawnDistance = 500.0

-- Repair duration in milliseconds (20s = 20000)
Config.RepairDuration = 20000
