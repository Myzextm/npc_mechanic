ESX = exports['es_extended']:getSharedObject()

local mechanicModel = "s_m_m_autoshop_01"
local towTruckModel = "19raptor"
local mechanicPed, towVehicle, mechanicBlip = nil, nil, nil

RegisterCommand("mechanic", function()
    local playerPed = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(playerPed, false)

    if vehicle == 0 then
        ESX.ShowNotification("❌ Du bist in keinem Fahrzeug.")
        return
    end

    local vehicleCoords = GetEntityCoords(vehicle)
    local engineHealth = GetVehicleEngineHealth(vehicle)

    if engineHealth > 950.0 then
        ESX.ShowNotification("✅ Dein Fahrzeug ist nicht beschädigt.")
        return
    end

    ESX.ShowNotification("🔧 Ein Mechaniker macht sich auf den Weg...")

    -- Spawnpunkt 200m vom Fahrzeug entfernt suchen
    local spawnOffset = GetOffsetFromEntityInWorldCoords(vehicle, 200.0, 0.0, 0.0)
    local found, streetSpawn, heading = GetClosestVehicleNodeWithHeading(spawnOffset.x, spawnOffset.y, spawnOffset.z, 1, 3.0, 0)

    if not found then
        ESX.ShowNotification("⚠️ Keine geeignete Straße zum Spawnen gefunden.")
        return
    end

    -- Model laden
    RequestModel(mechanicModel)
    RequestModel(towTruckModel)
    while not HasModelLoaded(mechanicModel) or not HasModelLoaded(towTruckModel) do
        Wait(10)
    end

    -- Fahrzeug & NPC spawnen
    towVehicle = CreateVehicle(towTruckModel, streetSpawn.x, streetSpawn.y, streetSpawn.z, heading, true, false)
    SetVehicleColours(towVehicle, 88, 88) -- Gelb
    SetVehicleOnGroundProperly(towVehicle)

    mechanicPed = CreatePed(4, mechanicModel, streetSpawn.x, streetSpawn.y, streetSpawn.z, heading, true, false)
    TaskWarpPedIntoVehicle(mechanicPed, towVehicle, -1)

    -- Blip für Mechanikerfahrzeug
    mechanicBlip = AddBlipForEntity(towVehicle)
    SetBlipSprite(mechanicBlip, 67)
    SetBlipColour(mechanicBlip, 5)
    SetBlipScale(mechanicBlip, 0.8)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentSubstringPlayerName("Mechaniker")
    EndTextCommandSetBlipName(mechanicBlip)

    -- Mechaniker fährt zum Fahrzeug
    TaskVehicleDriveToCoord(mechanicPed, towVehicle, vehicleCoords.x, vehicleCoords.y, vehicleCoords.z, 30.0, 1, towTruckModel, 524863, 5.0)

    -- Beobachte den Mechaniker
    CreateThread(function()
        while true do
            Wait(2000)
            if not mechanicPed then break end

            local pedCoords = GetEntityCoords(mechanicPed)
            local dist = #(pedCoords - vehicleCoords)

            if dist < 10.0 then
                ClearPedTasks(mechanicPed)
                TaskLeaveVehicle(mechanicPed, towVehicle, 0)
                Wait(3000)

                -- Position zur Motorhaube (etwas näher)
                local engineBone = GetEntityBoneIndexByName(vehicle, "engine")
                if engineBone == -1 then
                    engineBone = GetEntityBoneIndexByName(vehicle, "bonnet")
                end
                local boneCoords = GetWorldPositionOfEntityBone(vehicle, engineBone)
                local vehHeading = GetEntityHeading(vehicle)

                local offsetX = 0.3 * math.cos(math.rad(vehHeading))
                local offsetY = 0.3 * math.sin(math.rad(vehHeading))
                local targetX = boneCoords.x + offsetX
                local targetY = boneCoords.y + offsetY
                local targetZ = boneCoords.z

                -- Gehe zur Motorhaube
                TaskGoStraightToCoord(mechanicPed, targetX, targetY, targetZ, 1.0, 20000, vehHeading, 0.0)
                Wait(4000)
                SetEntityHeading(mechanicPed, vehHeading - 180.0)

                -- Motorhaube öffnen
                SetVehicleDoorOpen(vehicle, 4, false, false)

                -- Reparaturanimation
                RequestAnimDict("mini@repair")
                while not HasAnimDictLoaded("mini@repair") do Wait(10) end
                TaskPlayAnim(mechanicPed, "mini@repair", "fixing_a_ped", 8.0, -8.0, 20000, 1, 0, false, false, false)

                ESX.ShowNotification("🔧 Der Mechaniker arbeitet am Motor...")
                Wait(20000)

                -- Fahrzeug reparieren
                ClearPedTasks(mechanicPed)
                SetVehicleFixed(vehicle)
                SetVehicleDeformationFixed(vehicle)
                SetVehicleUndriveable(vehicle, false)
                SetVehicleDoorShut(vehicle, 4, false)
                ESX.ShowNotification("✅ Reparatur abgeschlossen!")

                -- Rückfahrt
                TaskEnterVehicle(mechanicPed, towVehicle, 10000, -1, 1.0, 1, 0)
                Wait(5000)

                local awayCoords = GetOffsetFromEntityInWorldCoords(vehicle, 500.0, 500.0, 0)
                TaskVehicleDriveToCoord(mechanicPed, towVehicle, awayCoords.x, awayCoords.y, awayCoords.z, 30.0, 1, towTruckModel, 786603, 5.0)

                while true do
                    Wait(3000)
                    local distAway = #(GetEntityCoords(mechanicPed) - vehicleCoords)
                    if distAway > 500.0 then
                        DeletePed(mechanicPed)
                        DeleteVehicle(towVehicle)
                        RemoveBlip(mechanicBlip)
                        ESX.ShowNotification("📦 Der Mechaniker ist Zurück gefahren.")
                        mechanicPed, towVehicle, mechanicBlip = nil, nil, nil
                        break
                    end
                end
                break
            end
        end
    end)
end)
